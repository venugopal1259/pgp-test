package pgp.test.constants;

public final class PgpConstants {

	private PgpConstants() {
	}

	public static final String ENCRYPTED_FILE_SUFFIX = ".asc";

	public static final String KEY_STORE_PATH = "/keystore";
	
}
