package pgp.test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import pgp.test.utils.CryptoUtils;

import java.io.File;

@Slf4j
@Service
public class PgpTestService {

	@Value("${pgp.test.base-path}")
	private String basePath;

	@Autowired
	CryptoUtils cryptoUtils;

	public boolean decrypt(String fileName) {
		log.info("File Name : {}", fileName);
		String filePath = basePath + File.separator + fileName;
		log.info("File Full Path : {}", filePath);
		return cryptoUtils.process("0x1B923703", filePath, CryptoUtils.FileType.REGULAR, CryptoUtils.Action.DECRYPT);
	}

}
