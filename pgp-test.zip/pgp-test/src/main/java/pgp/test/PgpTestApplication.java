package pgp.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
@EntityScan(basePackages = "pgp.test")
public class PgpTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgpTestApplication.class, args);
	}
}