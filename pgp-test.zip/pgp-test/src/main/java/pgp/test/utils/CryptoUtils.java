package pgp.test.utils;

import lombok.extern.slf4j.Slf4j;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.BouncyGPG;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.algorithms.DefaultPGPAlgorithmSuites;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.callbacks.KeyringConfigCallbacks;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfig;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfigs;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.util.io.Streams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static pgp.test.constants.PgpConstants.*;

@Component
@Slf4j
public class CryptoUtils {

	public static final String CRYPTO_FILENAME = "crypto_filename.txt";

	public enum FileType {
		REGULAR
	}

	public enum Action {
		ENCRYPT, DECRYPT
	}

	@Value("${pgp.test.temp-path:/tmp}")
	private String tempFolder;

	private final KeyringConfig keyringConfig;

	@SuppressWarnings("deprecation")
	public CryptoUtils(@Value("${pgp.test.environment}") String environment,
			@Value("${pgp.test.base-path}") String basepath, @Value("${pgp.test.pgp.pass}") String keyRingPassword) {

		String gnupgHomeDir = basepath + File.separator + environment + KEY_STORE_PATH;

		String publicKeyRingName = String.format("%s/%s", gnupgHomeDir, "pubring.gpg");
		String secretKeyRingName = String.format("%s/%s", gnupgHomeDir, "secring.gpg");

		BouncyGPG.registerProvider();

		// Generating keyring from the gnupg folder contents
		keyringConfig = KeyringConfigs.withKeyRingsFromFiles(new File(publicKeyRingName), new File(secretKeyRingName),
				KeyringConfigCallbacks.withPassword(keyRingPassword));

		listPublicKeys();
	}

	private void listPublicKeys() {
		List<String> publicKeys = getPublicKeys();
		if (!publicKeys.isEmpty()) {
			log.info("Public keys in the key ring are the following:\n{}", String.join("\n", publicKeys));
		}
	}

	/**
	 * Returns the list of public keys in the public key ring as present in
	 * scripts/.gnupg folder in short id format.
	 *
	 * @return the list of public keys in keyring in short id format.
	 */
	public List<String> getPublicKeys() {
		List<String> publicKeys = new ArrayList<>();
		try {
			keyringConfig.getPublicKeyRings().getKeyRings()
					.forEachRemaining(keyRing -> keyRing.getPublicKeys().forEachRemaining(pgpPublicKey -> {
						String keyId = Long.toHexString(pgpPublicKey.getKeyID());
						if (pgpPublicKey.isMasterKey()) {
							publicKeys.add(String.format("0x%s", keyId.substring(keyId.length() - 8)).toUpperCase());
						}
					}));
		} catch (Exception e) {
			log.error("Exception raised while reading the public keys from key ring : {}", e.getMessage());
		}
		return publicKeys;
	}

	private String getKeyId(String keyId, Action action) {
		if (keyId.startsWith("0x")) {
			keyId = keyId.substring(2);
		}
		return keyId;
	}

	/**
	 * Entry point for encryption/decryption utilities.
	 *
	 * @param clientConfigArgs ClientConfigLine (client_config) line arguments
	 * @param inputFilePath    Input file with full file path
	 * @param type             Process type ( Reg for non-IDR, Idr for IDR)
	 * @param action           Action to perform ( Encrypt/Decrypt)
	 * @return True if the encryption/decryption succeeds, False otherwise
	 */
	public boolean process(String keyID, String inputFilePath, FileType type, Action action) {

		log.info("CryptoUtils::process : input file path : {}, file type : {}, action: {}", inputFilePath, type.name(),
				action.name());
		if (!checkIfFileExists(inputFilePath)) {
			return false;
		}
		String keyId = getKeyId(keyID, action);
		if (action == Action.DECRYPT) {
			// Decryption
			doDecryption(inputFilePath);
		} else {
			// Encryption
			doEncryption(keyId, inputFilePath);
		}
		return true;
	}

	private void doEncryption(String keyId, String inputFilePath) {
		Optional<String> longKeyId = getRecipientForID(keyId);
		if (longKeyId.isEmpty()) {
			log.info("public key {} is not present in the public key ring, please check", keyId);
			throw new RuntimeException("key not present in the public key ring");
		}
		String outputFilePath = String.format("%s.asc", inputFilePath);
		removeTrailingSpaces(inputFilePath);
		encryptFile(inputFilePath, outputFilePath, longKeyId.get());
		removeFile(inputFilePath);
		writeFileToTempFile(outputFilePath);
	}

	private void doDecryption(String inputFilePath) {
		String outputFilePath = inputFilePath.endsWith(".asc")
				? inputFilePath.substring(0, inputFilePath.lastIndexOf("."))
				: inputFilePath;
		decryptFile(inputFilePath, outputFilePath);
		removeFile(inputFilePath);
		writeFileToTempFile(outputFilePath);
	}

	/**
	 * Deletes the given file from file system
	 *
	 * @param filePath File name with full file path
	 */
	private void removeFile(String filePath) {
		try {
			Files.deleteIfExists(Path.of(filePath));
		} catch (IOException e) {
			log.info("Deletion of file {} failed, Please check.", filePath);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Removes trailing spaces in each lines of the input file inputFilePath
	 *
	 * @param inputFilePath file name with full path
	 */
	private void removeTrailingSpaces(String inputFilePath) {
		Path filePath = Paths.get(inputFilePath);
		try {
			String fileContent = Files.readString(filePath);
			String newFileContent = fileContent.replaceAll("\\s+$", "");
			Files.writeString(filePath, newFileContent, StandardCharsets.UTF_8);
		} catch (IOException e) {
			log.info("Exception occured while reading file {}", inputFilePath);
			throw new RuntimeException(e);
		}
	}

	// TODO file permissions change of the target Folder needs to be addressed

	/**
	 * Writes given filename inputFilePath to file crypto_filename.txt in temp
	 * folder specified in the configuration.
	 *
	 * @param inputFilePath Input file name
	 */
	private void writeFileToTempFile(String inputFilePath) {
		String targetFile = tempFolder + File.separator + CRYPTO_FILENAME;
		try {
			if (!Files.exists(Path.of(tempFolder))) {
				Files.createDirectories(Path.of(tempFolder));
			}

			Files.write(Paths.get(targetFile), inputFilePath.getBytes());
		} catch (IOException e) {
			log.info("Error occured while writing to file {}", targetFile);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Encrypts the given file inputFilePath and creates a new encrypted file
	 * encryptedFilePath using the recipient id. Generates encrypted data in an
	 * ascii armored format.
	 *
	 * @param inputFilePath     input file to be encrypted
	 * @param encryptedFilePath encrypted file name
	 * @param recipient         recipient id to be encrypted for Note that recipient
	 *                          should be present in the gpg keyring and should be
	 *                          configured properly in client_config
	 */
	private void encryptFile(String inputFilePath, String encryptedFilePath, String recipient) {

		try (final FileOutputStream fileOutput = new FileOutputStream(encryptedFilePath);
				final BufferedOutputStream bufferedOut = new BufferedOutputStream(fileOutput);

				final OutputStream outputStream = BouncyGPG.encryptToStream().withConfig(this.keyringConfig)
						.withAlgorithms(DefaultPGPAlgorithmSuites.strongSuite()).toRecipient(recipient).andDoNotSign()
						.armorAsciiOutput()
						// .binaryOutput() //TODO Need to check if we need non-ascii-armored output for
						// any clients
						.andWriteTo(bufferedOut);

				final FileInputStream is = new FileInputStream(inputFilePath)

		) {
			Streams.pipeAll(is, outputStream);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Gets the User id for the given short key in the keyring. Returns Empty if
	 * there's given key is not present in the keyring.
	 *
	 * @param shortKeyId Short key id present in the gpg keyring
	 * @return User id for the given short key id in the keyring.
	 */
	private Optional<String> getRecipientForID(String shortKeyId) {
		final String[] keyId = { null };
		String shortKeyIdLower = shortKeyId.toLowerCase();

		try {
			PGPPublicKeyRingCollection keyRingCollection = this.keyringConfig.getPublicKeyRings();
			Iterator<PGPPublicKeyRing> keyRings = keyRingCollection.getKeyRings();

			keyRings.forEachRemaining(keyRing -> {
				Iterator<PGPPublicKey> keys = keyRing.getPublicKeys();
				keys.forEachRemaining(key -> {
					String fullkeyId = Long.toHexString(key.getKeyID()).toLowerCase();
					if (fullkeyId.endsWith(shortKeyIdLower)) {
						keyId[0] = key.getUserIDs().next();
					}
				});
			});
		} catch (Exception e) {
			log.info("Exception occurred while searching for public key in gpg keyring : {}", e.getMessage());
			return Optional.empty();
		}

		return keyId[0] == null ? Optional.empty() : Optional.of(keyId[0]);
	}

	/**
	 * Decrypts the given encrypted file encFilePath into the file destFilePath.
	 * Requires the input file to be encrypted with the Cotiviti shared public key.
	 * Otherwise, throws error
	 *
	 * @param encFilePath  Encrypted file
	 * @param destFilePath Decrypted file path
	 */
	private void decryptFile(String encFilePath, String destFilePath) {

		log.info("Keyring config : {}", this.keyringConfig);
		try (final FileInputStream cipherTextStream = new FileInputStream(encFilePath);
				final FileOutputStream fileOutput = new FileOutputStream(destFilePath);
				final BufferedOutputStream bufferedOut = new BufferedOutputStream(fileOutput);

				final InputStream plaintextStream = BouncyGPG.decryptAndVerifyStream().withConfig(this.keyringConfig)
						.andIgnoreSignatures().fromEncryptedInputStream(cipherTextStream)) {
			log.info("Decryption process is ready to be processed");
			Streams.pipeAll(plaintextStream, bufferedOut);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Checks if the file exists in the file system Throws RuntimeException if the
	 * file does not exist, exits silently if file exists
	 *
	 * @param inputFilePath input file with full file path
	 */
	private static boolean checkIfFileExists(String inputFilePath) {
		if (!Files.exists(Path.of(inputFilePath))) {
			log.info("ERROR: File {} not found", inputFilePath);
			return false;
		}
		return true;
	}

}
