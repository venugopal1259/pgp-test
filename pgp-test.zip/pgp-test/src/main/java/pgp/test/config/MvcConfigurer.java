package pgp.test.config;

import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.mvc.method.annotation.PrincipalMethodArgumentResolver;

import java.util.List;

/*
 * Added this file to resolve the @AuthenticationPrincipal annotation. Either remove the annotation altogether or use this resolver.
 * From spring boot version 2.4, java.security.Principal argument is no longer resolved eagerly, 
 * if it is annotated in some way such as @AuthenticationPrincipal, 
 * thus allowing a custom resolver to resolve it first, before using default resolution resolution via HttpServletRequest#getUserPrincipal
*/
//@Configuration
public class MvcConfigurer implements WebMvcConfigurer {
	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
		resolvers.add(new PrincipalMethodArgumentResolver());
	}
}